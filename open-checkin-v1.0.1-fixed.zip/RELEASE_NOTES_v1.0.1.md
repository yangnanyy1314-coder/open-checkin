# Open Check-in v1.0.1

## Added
- Training program type selector in learner settings
- Presets for general, AI, content creation, language learning, professional skills, and personal growth
- Selected program type persists with the learner profile
- Program type appears in exported reports
- Visible v1.0.1 version marker

## Compatibility
Existing 14-day check-in data and the local-first storage model remain unchanged.
